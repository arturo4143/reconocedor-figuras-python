# -*- coding: utf-8 -*-
""" @package Proyecto
Created on Wed Jun 29 16:54:28 2016

@author: Dr. Pedro
"""

import json
from PIL import Image
import numpy as np
import math

BIG_NUMBER = 9999999999

def puntosFromJson(jsonFile):
    #se lee el json file
    jsonData=open(jsonFile)
    data = json.load(jsonData)
    jsonData.close()
    #se crea la variable de retorno
    puntos = {'x': [], 'y': []}
    #se extraen las coordenadas en x
    nPoints=len(data['dibujo']['coordenadas'])
    for i in range(nPoints):
        puntos['x'].append(data['dibujo']['coordenadas'][i]['X'])    
        puntos['y'].append(data['dibujo']['coordenadas'][i]['Y'])    
    return puntos

# puntos es de la forma {'x': [], 'y': []}
def puntos2matriz(puntos):    
    minx=min(puntos['x'])
    maxx=max(puntos['x'])
    miny=min(puntos['y'])
    maxy=max(puntos['y'])
    nPoints=len(puntos['x'])
    imagen=np.zeros((maxy-miny+1,maxx-minx+1),dtype='uint8')
    for i in range(0, nPoints):
        if(puntos['x'][i]>=minx and puntos['x'][i]<=maxx)and(puntos['y'][i]>=miny and puntos['y'][i]<=maxy):
            imagen[puntos['y'][i]-miny,puntos['x'][i]-minx]=1
    return imagen

# puntos es de la forma {'x': [], 'y': []}
def puntos2matrizConectada(puntos):
    minx=min(puntos['x'])
    maxx=max(puntos['x'])
    miny=min(puntos['y'])
    maxy=max(puntos['y'])
    nPoints=len(puntos['x'])
    m = p1x = p1y = p2x = p2y = 0
    imagen=np.zeros((maxy-miny+1,maxx-minx+1),dtype='uint8')   
    for i in range(0, nPoints):
        if(i==(nPoints-1)):
            #punto actual y futuro
            p1x = puntos['x'][-1]-minx
            p1y = puntos['y'][-1]-miny     
            p2x = puntos['x'][0]-minx
            p2y = puntos['y'][0]-miny                
        else:      
            #punto actual y futuro
            p1x = puntos['x'][i]-minx
            p1y = puntos['y'][i]-miny     
            p2x = puntos['x'][i+1]-minx
            p2y = puntos['y'][i+1]-miny
        #si los dos puntos son el mismo
        if((p1x == p2x) and (p1y == p2y)):
            continue                         
#       print('p1:('+str(p1x)+','+str(p1y)+') - '+ 'p2:('+str(p2x)+','+str(p2y)+')')
        minX = p1x if (p1x<p2x) else p2x
        minY = p1y if (p1y<p2y) else p2y
        nPuntosIntermedios = int(math.sqrt((p2x-p1x)**2 + (p2y-p1y)**2) + 1)
        #pendiente y b
        m = BIG_NUMBER if ((p2x-p1x)==0) else (p2y-p1y)/(p2x-p1x)
        b = p1x if (m == BIG_NUMBER) else -m*p1x+p1y
        for nIncremento in range(0, nPuntosIntermedios+1):
            if m == BIG_NUMBER:
                incrementoY = abs((p1y-p2y)/nPuntosIntermedios);
                newX = minX 
                newY = minY + nIncremento*incrementoY        
            else:
                incrementoX = abs((p1x-p2x)/nPuntosIntermedios);
                newX = minX + nIncremento*incrementoX
                newY = m*newX+b
            imagen[newY,newX]=1    
    return imagen    
# puntos a imagen
# puntos es de la forma {'x': [], 'y': []}
def puntos2imagen(puntos, filename):
    matriz = puntos2matriz(puntos)
    img=Image.fromarray(255*matriz)
    img.save(filename)    
    ######################################################################################################
def distSup(img,columna,filas):#función para calcular la distancia entre el borde superior de la imagen y el pixel 255 más cercano verticalmente
    flag=False
    i=0
    cont=0
    while(flag!=True):
        if(img[i,columna]==0):
            cont=cont+1
            i=i+1
        else:
            flag=True
    cont=cont/filas
    return cont          
def distInf(img,columna,filas):#función para calcular la distancia entre el borde inferior de la imagen y el pixel 255 más cercano verticalmente
    flag=False
    i=filas-1
    cont=0
    while(flag!=True):
        if(img[i,columna]==0):
            cont=cont+1
            i=i-1
        else:
            flag=True 
    cont=cont/filas
    return cont    
def distIzq(img,fila,columnas):#función para calcular la distancia entre el borde izquierdo de la imagen y el pixel 255 más cercano horizontalmente
    flag=False
    i=0
    cont=0
    while(flag!=True):
        if(img[fila,i]==0):
            cont=cont+1
            i=i+1
        else:
            flag=True
    cont=cont/columnas
    return cont          
def distDer(img,fila,columnas):#función para calcular la distancia entre el borde derecho de la imagen y el pixel 255 más cercano verticalmente
    flag=False
    i=columnas-1
    cont=0
    while(flag!=True):
        if(img[fila,i]==0):
            cont=cont+1
            i=i-1
        else:
            flag=True 
    cont=cont/columnas
    return cont