import math
# puntos es de la forma {'x': [], 'y': []}
def promedio(puntos):
    distancias=[]
    distanciaTotal=0
    distanciaAcumulada=0
    distanciasSeleccionadas=[]    
    puntosRet = {'x': [], 'y': []}
    nPoints=len(puntos['x'])

    # se calculan las distancias de los pountos subyacentes
    for i in range(nPoints-1):
        d = math.sqrt((puntos['x'][i]-puntos['x'][i+1])**2 + (puntos['y'][i]-puntos['y'][i+1])**2)
        distanciaTotal+=d
        distancias.append(d)
    #promedio
    distanciaPromedio = distanciaTotal/nPoints


    for i in range(len(distancias)):
        tempDis=distanciaAcumulada+distancias[i]
        if i == 0:
            puntosRet['x'].append(puntos['x'][i])
            puntosRet['y'].append(puntos['y'][i])
        else:
            if (tempDis >   distanciaPromedio):
                distanciasSeleccionadas.append(tempDis)
                puntosRet['x'].append(puntos['x'][i+1])        
                puntosRet['y'].append(puntos['y'][i+1])
                distanciaAcumulada=0                
            else:
                distanciaAcumulada+=distancias[i]
    return puntosRet
    
# puntos es de la forma {'x': [], 'y': []}
def decimacion(puntos, factor=3):
    puntosDecimandos = {'x': [], 'y': []}
    nPoints=len(puntos['x'])
    for i in range(nPoints):
        if ((i+1) % factor == 1):
            puntosDecimandos['x'].append(puntos['x'][i])
            puntosDecimandos['y'].append(puntos['y'][i])        
    return puntosDecimandos